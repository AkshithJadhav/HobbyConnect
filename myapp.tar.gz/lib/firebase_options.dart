// File created by FlutterFire CLI.
// ignore_for_file: lines_longer_than_80_chars, avoid_classes_with_only_static_members

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'AIzaSyDsP46hjXZDYXee66f5q0fUx5it_XfCPbw',
    appId: '1:317053964861:android:6ffec8bb9d8a49b4759054',
    messagingSenderId: '317053964861',
    projectId: 'hobbyconnect-9feaa',
    storageBucket: 'hobbyconnect-9feaa.appspot.com',
  );
}
